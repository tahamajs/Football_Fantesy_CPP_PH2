#include "../include/System.hpp"
#include "../include/InputHandler.hpp"
#include <iostream>

int main()
{
    InputHandler input_handler;
    input_handler.run();

    return 0;
}